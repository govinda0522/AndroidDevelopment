package com.example.java2;

import androidx.appcompat.app.AppCompatActivity;

import android.os.Bundle;
import android.widget.TextView;

public class MainActivity extends AppCompatActivity {

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        TextView textView=new TextView(this);
        textView.setText("Woohh!!");
        super.onCreate(savedInstanceState);
        setContentView(textView);
    }
}