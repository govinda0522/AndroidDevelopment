package com.example.secondapp;

import androidx.appcompat.app.AppCompatActivity;

import android.os.Bundle;
import android.util.Log;
import android.view.View;
import android.widget.CheckBox;
import android.widget.TextView;

import java.text.NumberFormat;

public class MainActivity extends AppCompatActivity {

    int quantity=5;
    int price=10;
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);
    }
    public void SubmitOrder(View view)
    {
        /*display(quantity);
        displayPrice(price*quantity);*/
       CheckBox cb1=(CheckBox)findViewById(R.id.Whipped_Cream1);
       boolean hasWhippedCream=cb1.isChecked();
        CheckBox cb2=(CheckBox)findViewById(R.id.Chocolate1);
        boolean hasChocolate=cb2.isChecked();
        price=calculatePrice();
        String priceMessage=createOrderSummary(price,hasWhippedCream,hasChocolate);
        displayMessage(priceMessage);

    }
    public String createOrderSummary(int price,boolean hasWhippedCream,boolean hasChocolate)
    {
        String priceMessage="Name  : Govinda ";
                priceMessage+="\nWhipped Cream ? "+hasWhippedCream;
                priceMessage+="\nhasChocolate ? "+hasChocolate;
               priceMessage+="\nQuantity       : "+quantity;
               priceMessage+="\nPrice       : "+price;
               priceMessage+="\n"+"Thank you !!";
         return priceMessage;

    }
    public void displayQuantity(int number)
    {
        TextView t2=(TextView)findViewById(R.id.t2);
        t2.setText(""+number);
    }
    public int calculatePrice()
    {
        return quantity*5;
    }


    public void increment(View view)
    {
        quantity++;
        displayQuantity(quantity);
    }
    public void decrement(View view)
    {
        quantity--;
        displayQuantity(quantity);

    }
    public void displayMessage(String priceMessage) {
        TextView t4=(TextView)findViewById(R.id.t4);
        t4.setText(priceMessage);
    }


}