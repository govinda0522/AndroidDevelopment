package com.example.orderfoodonline;
/*
import androidx.appcompat.app.AppCompatActivity;

import android.os.Bundle;

public class MainActivity extends AppCompatActivity {

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);
    }
}
 */

import android.content.Intent;
import android.net.Uri;
import android.os.Bundle;
import android.view.View;
import android.widget.CheckBox;
import android.widget.EditText;
import android.widget.TextView;

import androidx.appcompat.app.AppCompatActivity;

public class MainActivity extends AppCompatActivity {

    int quantity = 5;
    int price = 10;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);
    }

    public void SubmitOrder(View view) {

        EditText textName = (EditText) (findViewById(R.id.Name));
        String Name = (String) textName.getText().toString();
        CheckBox cb1 = (CheckBox) findViewById(R.id.Whipped_Cream1);
        boolean hasWhippedCream = cb1.isChecked();
        CheckBox cb2 = (CheckBox) findViewById(R.id.Chocolate1);
        boolean hasChocolate = cb2.isChecked();
        price = calculatePrice(hasWhippedCream, hasChocolate);
        String priceMessage = createOrderSummary(price, hasWhippedCream, hasChocolate, Name);

        Intent intent = new Intent(Intent.ACTION_SENDTO);
        intent.setData(Uri.parse("mailto:")); // only email apps should handle this

        intent.putExtra(Intent.EXTRA_SUBJECT, "Just Java Order for " + Name);
        intent.putExtra(Intent.EXTRA_TEXT, priceMessage);
        if (intent.resolveActivity(getPackageManager()) != null) {
            startActivity(intent);
        }


    }

    public String createOrderSummary(int price, boolean hasWhippedCream, boolean hasChocolate, String Name) {
        String priceMessage = "Name  : " + Name;
        priceMessage += "\nAdd Whipped Cream ? " + hasWhippedCream;
        priceMessage += "\nAdd Chocolate ? " + hasChocolate;
        priceMessage += "\nQuantity       : " + quantity;
        priceMessage += "\nPrice       : " + price;
        priceMessage += "\n" + "Thank you !!";
        return priceMessage;

    }

    public void displayQuantity(int number) {
        TextView t2 = (TextView) findViewById(R.id.t2);
        t2.setText("" + number);
    }

    public int calculatePrice(boolean hasWhippedCream, boolean hasChocolate) {
        int basePrice = 5;
        if (hasWhippedCream) {
            basePrice += 1;
        }
        if (hasChocolate) {
            basePrice += 2;
        }
        return basePrice * quantity;
    }


    public void increment(View view) {
        quantity++;
        displayQuantity(quantity);
    }

    public void decrement(View view) {
        quantity--;
        displayQuantity(quantity);

    }
}


