package com.example.basketballbygovinda;

import androidx.appcompat.app.AppCompatActivity;

import android.os.Bundle;
import android.view.View;
import android.widget.TextView;

public class MainActivity extends AppCompatActivity {

    long Sa=0,Sb=0;;
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);
    }
    public void Method_plus1A(View view)
    {
        TextView ScoreA=(TextView)findViewById(R.id.ScoreA);
        Sa+=1;
        ScoreA.setText(Sa+"");
    }
    public void Method_plus2A(View view)
    {
        TextView ScoreA=(TextView)findViewById(R.id.ScoreA);
        Sa+=2;
        ScoreA.setText(Sa+"");
    }
    public void Method_plus3A(View view)
    {
        TextView ScoreA=(TextView)findViewById(R.id.ScoreA);
        Sa+=3;
        ScoreA.setText(Sa+"");
    }
    public void Method_plus1B(View view)
    {
        TextView ScoreB=(TextView)findViewById(R.id.ScoreB);
        Sb+=1;
        ScoreB.setText(Sb+"");
    }
    public void Method_plus2B(View view)
    {
        TextView ScoreB=(TextView)findViewById(R.id.ScoreB);
        Sb+=2;
        ScoreB.setText(Sb+"");
    }
    public void Method_plus3B(View view)
    {
        TextView ScoreB=(TextView)findViewById(R.id.ScoreB);
        Sb+=3;
        ScoreB.setText(Sb+"");
    }
    public void reset(View view)
    {
        TextView ScoreA=(TextView)findViewById(R.id.ScoreA);
        TextView ScoreB=(TextView)findViewById(R.id.ScoreB);
        Sa=0;
        Sb=0;
        ScoreA.setText(Sa+"");
        ScoreB.setText(Sb+"");
    }

}